$(document).ready(function () {



    //HERO SLIDER
});
