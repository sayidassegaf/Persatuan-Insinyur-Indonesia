



<?php $__env->startSection('container'); ?>
    <div class="container">
        <h1>Daftar Anggota</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <form action="<?php echo e(route('anggota.index')); ?>" method="GET">
                <div class="form-group mb-0">
                    <input type="text" name="q" class="form-control" placeholder="Cari anggota..." value="<?php echo e(request('q')); ?>">
                </div>
            </form>
            <a href="<?php echo e(route('anggota.create')); ?>" class="btn btn-primary">Tambah Anggota</a>
        </div>
        <table class="table mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Telepon</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($anggota->id); ?></td>
                        <td><?php echo e($anggota->nama); ?></td>
                        <td><?php echo e($anggota->email); ?></td>
                        <td><?php echo e($anggota->telepon); ?></td>
                        <td><?php echo e(ucfirst($anggota->status)); ?></td>
                        <td>
                            <a href="<?php echo e(route('anggota.show', $anggota->id)); ?>" class="btn btn-sm btn-primary">Lihat</a>
                            <a href="<?php echo e(route('anggota.edit', $anggota->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('anggota.destroy', $anggota->id)); ?>" method="POST" class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($anggotas->appends(['q' => request('q')])->links()); ?>

    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\WebPrograming\persatuan-insinyur\resources\views/anggota/index.blade.php ENDPATH**/ ?>