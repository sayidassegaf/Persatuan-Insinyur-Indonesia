<?php $__env->startSection('container'); ?>
  <h1 class="mb-3 text-center"><?php echo e($title); ?></h1>

  <div class="row justify-content-center mb-3">
    <div class="col-md-6">
      <form action="/posts">
        <?php if(request('category')): ?>
          <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
        <?php endif; ?>
        <?php if(request('author')): ?>
          <input type="hidden" name="author" value="<?php echo e(request('author')); ?>">
        <?php endif; ?>
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Search.." name="search" value="<?php echo e(request('search')); ?>">
          <button class="btn btn-danger" type="submit">Search</button>
        </div>
      </form>
    </div>
  </div>


  <?php if($posts->count()): ?>
    
  
  
  <div class="container">
    <div class="row">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-3">
          <div class="card-deck">
            <div class="card text-center border-0">
            
            <?php if($post->image): ?>           
              <img src="<?php echo e(asset('storage/' . $post->image)); ?>"
              alt="<?php echo e($post->category->name); ?>" class="img-fluid rounded-circle mx-auto" width="256">
            <?php else: ?>
              <img src="https://source.unsplash.com/500x400?<?php echo e($post->category->name); ?>" class="card-img-top rounded-circle" alt="<?php echo e($post->category->name); ?>">
            <?php endif; ?>
            
            <div class="card-body">
              <h5 class="card-title"><?php echo e($post->title); ?></h5>
              <p>
                <small class="text-muted">
                  <i class="bi bi-geo-alt"> </i>
                  
                  
                </small>
              </p>
              <p class="card-text"><i class="bi bi-gear"> </i><?php echo e($post->excerpt); ?> <br>
                <i class="bi bi-mortarboard-fill"> </i><?php echo e($post->category->slug); ?>

              
              </p>
              
            </div>
          
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <?php else: ?>
    <p class="text-center fs-4">No post found.</p>
  <?php endif; ?>

  <div class="d-flex justify-content-center">
    <?php echo e($posts->links()); ?>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\WebPrograming\persatuan-insinyur\resources\views/posts.blade.php ENDPATH**/ ?>